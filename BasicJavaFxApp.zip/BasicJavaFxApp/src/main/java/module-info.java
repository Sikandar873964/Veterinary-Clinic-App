module com.mycompany.basicjavafxapp {
    requires javafx.controls;
    exports com.mycompany.basicjavafxapp;
}
