//Store
/**
 *The Details that are entered by the user is fetched from MyAnimalStore
 *
 * @author Sikandar
 * @version 5.0
 */
package com.mycompany.basicjavafxapp;

import java.io.Serializable;
import java.util.ArrayList;

public class MyAnimalStore implements Serializable {

    private final ArrayList<Animal> animalsForTreatment;
    public final int MAX;

    public MyAnimalStore(int maxIn) {
        animalsForTreatment = new ArrayList<>();
        MAX = maxIn;
    }

    public String addAnimal(Animal theAnimal) {
        if (!isFull()) {

            animalsForTreatment.add(theAnimal);
            return theAnimal.name + "Successfully Added";
        } else {
            return "Sorry, there is no space at the momenet in the clinic";
        }
    }

    public boolean isEmpty() {
        return animalsForTreatment.isEmpty();
    }

    public boolean isFull() {

        boolean fullChecker;
        if (animalsForTreatment.size() <= MAX) {
            fullChecker = false;
        } else {
            fullChecker = true;
        }
        return fullChecker;
    }

    public String displayAnimals() {
        String output = "\n";
        for (int counter = 0; counter < animalsForTreatment.size(); counter++) {
            //Display owner information
            output += "\n" + "Owner Information ";
            output += "\n" + "First Name: " + animalsForTreatment.get(counter).holderName;
            output += "\n" + "Surname: " + animalsForTreatment.get(counter).holderSurname;
            output += "\n" + "Address: " + animalsForTreatment.get(counter).address;
            output += "\n";
            output += "\n" + "Animal Information: ";
            output += "\n" + "Animal Name: " + animalsForTreatment.get(counter).name;
            output += "\n" + "Age: " + animalsForTreatment.get(counter).age;
            output += "\n" + "Breed: " + animalsForTreatment.get(counter).breed;
            output += "\n" + "Pet Health Issue: " + animalsForTreatment.get(counter).symptom;
            output += "\n" + "Gender: " + animalsForTreatment.get(counter).gender;
            output += "\n" + "Colour: " + animalsForTreatment.get(counter).colour + "\n";
            output += "\n" + "********************************************";
            output += "\n";
        }
        return output;
    }

}
