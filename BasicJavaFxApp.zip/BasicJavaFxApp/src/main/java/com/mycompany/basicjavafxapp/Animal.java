package com.mycompany.basicjavafxapp;

import java.io.Serializable;

/**
 * Animal Variable are defined here
 * @author Sikandar
 * 
 */
public class Animal implements Serializable{
    String name;
    String age;
    String breed;
    String symptom;
    String gender;
    String address;
    String colour;
    String holderName;
    String holderSurname;

    public Animal(String name, String age, String bread, String symptom, String gender, String address, String colour, String holderName, String holderSurname) {
        this.name = name;
        this.age = age;
        this.breed = bread;
        this.symptom = symptom;
        this.gender = gender;
        this.address = address;
        this.colour = colour;
        this.holderName = holderName;
        this.holderSurname = holderSurname;
    }

    public String getHolderName() {
        return holderName;
    }

    public String getHolderSurname() {
        return holderSurname;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public void setHolderSurname(String holderSurname) {
        this.holderSurname = holderSurname;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBreed() {
        return breed;
    }

    public void setBread(String breed) {
        this.breed = breed;
    }

    public String getSymptom() {
        return symptom;
    }

    public void setSymptom(String symptom) {
        this.symptom = symptom;
    }

    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }

    public String getColour() {
        return colour;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }
    
    
    
    
}
