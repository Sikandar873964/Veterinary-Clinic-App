package com.mycompany.basicjavafxapp;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
//import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * GUI for the Veterinary Clinic App
 *
 * @author Sikandar Butt
 */
public class App extends Application {

    //this is the trick. Have class that contains an arrayList here
    //this class can be used for added, deleting and searching for items
    //you will create the object in the start method
    private MyAnimalStore currentWaitinglList;

    // WIDTH and HEIGHT of GUI stored as constants 
    private final int WIDTH = 900;
    private final int HEIGHT = 900;

    // visual components
    private final Label headingLabel = new Label("Welcome to Sikandar's Veterinary Clinic");
    private final Label animalLabel = new Label("Animal Details");
    private final Label animalNameLabel = new Label("Animal Name");
    private final TextField animalNameField = new TextField();
    private final Label animalAgeLabel = new Label("Age");
    private final TextField animalAgeField = new TextField();
    private final Label animalBreedLabel = new Label("Breed");
    private final TextField animalBreedField = new TextField();
    private final Label healthLabel = new Label("Health Issue");
    private final TextField healthField = new TextField();
    private final Label genderLabel = new Label("Gender");
    private final TextField genderField = new TextField();
    private final Label addressLabel = new Label("Address");
    private final TextField addressField = new TextField();
    private final Label colourLabel = new Label("Colour");
    private final TextField colourField = new TextField();

    private final Separator sectSeparator = new Separator();
    private final Separator sectSeparator2 = new Separator();
    private final Separator sectSeparator3 = new Separator();
    private final Separator sectSeparator4 = new Separator();

    private final Label holderLabel = new Label("Holder Details");
    private final Label holderNameLabel = new Label("Given Name");
    private final TextField holderNameField = new TextField();
    private final Label holderSurnameLabel = new Label("Surname");
    private final TextField holderSurnameField = new TextField();

    private final TextArea displayAnimals = new TextArea();
    private final Button addButton = new Button("Book in");
    private final Button addSaveButton = new Button("Save Data");
    private final Button addClearButton = new Button("Clear");

    @Override
    public void start(Stage stage) {

        if (!showAllData()) {
            currentWaitinglList = new MyAnimalStore(50);
        }

        //This is a class to that will contain the animal. 
        //The parameter represents the maximum number of Animals in the waiting list.
        //create horizontal boxes for the animal and the owner details.
        HBox animalDetails = new HBox(10);
        HBox ownerDetails = new HBox(10);
        HBox groupButtons = new HBox(10);

        animalDetails.getChildren().addAll(animalNameLabel, animalNameField, animalAgeLabel, animalAgeField, animalBreedLabel, animalBreedField, healthLabel, healthField, genderLabel, genderField, colourLabel, colourField);

        ownerDetails.getChildren().addAll(holderNameLabel, holderNameField, holderSurnameLabel, holderSurnameField, addressLabel, addressField);
        groupButtons.getChildren().addAll(addButton, addSaveButton, addClearButton);
        VBox root = new VBox(10);
        root.getChildren().addAll(headingLabel, sectSeparator, animalLabel, animalDetails, sectSeparator2, holderLabel, ownerDetails, sectSeparator3, displayAnimals, sectSeparator4, groupButtons);

        Scene scene = new Scene(root, Color.web("#2196F3"));

        Font font = new Font("Vedana", 40);
        headingLabel.setFont(font);
        font = new Font("Vedana", 20);

        animalLabel.setFont(font);
        holderLabel.setFont(font);

        animalDetails.setAlignment(Pos.CENTER);
        ownerDetails.setAlignment(Pos.CENTER);
        addButton.setAlignment(Pos.CENTER);
        addSaveButton.setAlignment(Pos.CENTER);
        addClearButton.setAlignment(Pos.CENTER);

        root.setAlignment(Pos.CENTER);
        root.setBackground(Background.EMPTY);

        displayAnimals.setMaxSize(400, 700);
        displayAnimals.appendText(currentWaitinglList.displayAnimals());
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);

        addButton.setOnAction(e -> addHandler());

//        var javaVersion = SystemInfo.javaVersion();
//        var javafxVersion = SystemInfo.javafxVersion();
//
//        var label = new Label("Hello, JavaFX " + javafxVersion + ", running on Java " + javaVersion + ".");
//        var scene = new Scene(new StackPane(label), 640, 480);
        stage.setScene(scene);
        stage.show();

        addSaveButton.setOnAction(e -> addAllData());

        stage.setScene(scene);
        stage.show();

        addClearButton.setOnAction(e -> clearAnimalList());

        stage.setScene(scene);
        stage.show();

    }

    private void addHandler() {
        String animalName = animalNameField.getText();
        String animalAge = animalAgeField.getText();
        String animalBreed = animalBreedField.getText();
        String animalHealth = healthField.getText();
        String animalGender = genderField.getText();
        String animalAddress = addressField.getText();
        String animalColour = colourField.getText();
        String holderName = holderNameField.getText();
        String holderSurname = holderSurnameField.getText();
        String storeMessage;
        // check for errors
        if (animalName.length() == 0 || animalAge.length() == 0 || animalBreed.length() == 0) {
            displayAnimals.setText("You must enter Name, Age, Breed and Health issue of the animal.");
        } else if (holderName.length() == 0 || holderSurname.length() == 0) {
            displayAnimals.setText("You must enter both your given name and surname");
        } else // ok to add a Tenant
        {
            //String animalType, String name, String age, String bread, String symptom,Person thePerson
            //Animal animalToAdd;
            Animal animalToAdd = new Animal(animalName, animalAge, animalBreed, animalHealth, animalGender, animalAddress, animalColour, holderName, holderSurname);
            storeMessage = currentWaitinglList.addAnimal(animalToAdd);
            //clear the fields
            animalNameField.setText("");
            animalAgeField.setText("");
            animalBreedField.setText("");
            healthField.setText("");
            holderNameField.setText("");
            holderSurnameField.setText("");
            genderField.setText("");
            addressField.setText("");
            colourField.setText("");
            displayAnimals.setText("");
            displayAnimals.appendText(storeMessage);
            displayAnimals.appendText(animalName + " Successfully Added");
            displayAnimals.appendText("\nThe Animals waiting to be checked are: ");
            displayAnimals.appendText(currentWaitinglList.displayAnimals());
        }

    }

    public static void main(String[] args) {
        launch();
    }

    /**
     * @addAllData refers to Serialization
     */
    private void addAllData() {
        try {
            FileOutputStream fileOut = new FileOutputStream("./dataSer.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(currentWaitinglList);
            out.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in ./dataSer.ser file");
        } catch (IOException myException) {
            myException.printStackTrace();
        }
    }

    /**
     * @showAllData refers to De-serialization
     */
    private boolean showAllData() {
        Object obj;
        try {
            FileInputStream fileIn = new FileInputStream("./dataSer.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            obj = in.readObject();
            currentWaitinglList = (MyAnimalStore) obj;
            in.close();
            fileIn.close();
            currentWaitinglList.displayAnimals();
            return true;
        } catch (IOException i) {
            i.printStackTrace();
            return false;
        } catch (ClassNotFoundException c) {
            System.out.println("MyAnimalStore class not found");
            c.printStackTrace();
            return false;
        }
    }

    /**
     * @clearAnimalData refers to clearing all the patient list.
     */
    private void clearAnimalList() {

        animalNameField.setText("");
        animalAgeField.setText("");
        animalBreedField.setText("");
        healthField.setText("");
        holderNameField.setText("");
        holderSurnameField.setText("");
        genderField.setText("");
        addressField.setText("");
        colourField.setText("");
        displayAnimals.setText("");
    }

}
