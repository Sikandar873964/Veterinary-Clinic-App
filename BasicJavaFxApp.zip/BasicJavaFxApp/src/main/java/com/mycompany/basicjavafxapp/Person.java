package com.mycompany.basicjavafxapp;

import java.io.Serializable;

/**
 *
 * @author Sikandar
 */
public class Person implements Serializable{
    String holderName;
    String holderSurname;

    public String getHolderName() {
        return holderName;
    }

    public String getHolderSurname() {
        return holderSurname;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public void setHolderSurname(String holderSurname) {
        this.holderSurname = holderSurname;
    }
}
